﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;



    public partial class ControleDeMaterial : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        if (!Page.IsPostBack)
        {
            CarregaMaterial();
        }
        }

    protected void btn_Incluir_Click(object sender, EventArgs e)
    {
        
        try
        {
            SqlConnection cnx = new SqlConnection(new ClsFuncoes().conexao);
            cnx.Open();
            string sqltxt = string.Format("INSERT INTO MATERIAIS(TipoMercadoria, NomeDaMercadoria, Quantidade, Preco, TipodeNegocio) VALUES(@TipoMercadoria,@NomeDaMercadoria,@Quantidade,@Preco,@TipodeNegocio)", new ClsFuncoes().conexao);
            SqlCommand cmd = new SqlCommand(sqltxt, cnx);
            cmd.Parameters.AddWithValue("@TipoMercadoria", txt_TipodeMercadoria.Text);
            cmd.Parameters.AddWithValue("@NomeDaMercadoria", txt_Nome.Text);
            cmd.Parameters.AddWithValue("@Quantidade", txt_Quantidade.Text);
            cmd.Parameters.AddWithValue("@Preco", txt_Preco.Text);
            cmd.Parameters.AddWithValue("@TipodeNegocio", txt_TipodeNegocio.Text);
            cmd.ExecuteNonQuery();
            txt_TipodeMercadoria.Text = "";
            txt_Nome.Text = "";
            txt_Quantidade.Text = "";
            txt_Preco.Text = "";
            txt_TipodeNegocio.Text = "";
            CarregaMaterial();
        }
        catch(Exception erx)
        {
            lbl_msg.Text = "OCORREU UM ERRO NO BANCO DE DADOS";
        }
    }

    void CarregaMaterial()
    {

        gvw_ControleDeMaterial.DataSource = new ClsFuncoes().AbrirTabela("Select * FROM MATERIAIS");
        gvw_ControleDeMaterial.DataBind();

    }

}